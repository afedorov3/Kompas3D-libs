# numeric-edit
MFC CEdit derived control to input only numeric values
