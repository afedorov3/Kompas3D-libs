var searchData=
[
  ['updatebackcolor',['UpdateBackColor',['../class_c_grid_column_trait_text.html#a829800d676cfee5e9cd27a4f19c6cb19',1,'CGridColumnTraitText::UpdateBackColor()'],['../class_c_grid_row_trait_text.html#a313ee25248ac19e030ac4e8081973ce5',1,'CGridRowTraitText::UpdateBackColor()']]],
  ['updatetextcolor',['UpdateTextColor',['../class_c_grid_column_trait_hyper_link.html#ac5875c2e0325a39e7f0bc85170ce5895',1,'CGridColumnTraitHyperLink::UpdateTextColor()'],['../class_c_grid_column_trait_text.html#a3c255e5e444d504b037ba49608aaf460',1,'CGridColumnTraitText::UpdateTextColor()'],['../class_c_grid_row_trait_text.html#a2f0da7a1cfa5677dca654fb1bc821f19',1,'CGridRowTraitText::UpdateTextColor()']]],
  ['updatetextfont',['UpdateTextFont',['../class_c_grid_column_trait_hyper_link.html#aed49ea587d454cf8857d778e289c6880',1,'CGridColumnTraitHyperLink::UpdateTextFont()'],['../class_c_grid_column_trait_text.html#a02616da1f73d28e49a1c0ce6baca01ac',1,'CGridColumnTraitText::UpdateTextFont()']]]
];
